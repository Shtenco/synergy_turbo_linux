/*
 * Turbo Scheduler Kernel Module Implementation
 * Copyright (C) 2026 - VirtualQubit HPC Team
 * 
 * Qubit-aware real-time scheduler for HPC workloads
 */

#include "turbo_sched.h"

/* Module parameters */
static int turbo_enabled = 1;
static int turbo_debug = 0;
static int turbo_update_interval = 10; /* ms */

module_param(turbo_enabled, int, S_IRUGO | S_IWUSR);
module_param(turbo_debug, int, S_IRUGO | S_IWUSR);
module_param(turbo_update_interval, int, S_IRUGO | S_IWUSR);

MODULE_LICENSE("GPL");
MODULE_AUTHOR("VirtualQubit HPC Team");
MODULE_DESCRIPTION("Turbo Scheduler for HPC and Qubit Workloads");
MODULE_VERSION("1.0");

/* Global scheduler instance */
static struct turbo_scheduler *turbo_sched = NULL;

/* File operations */
static const struct file_operations turbo_sched_fops = {
    .owner = THIS_MODULE,
    .unlocked_ioctl = turbo_sched_ioctl,
};

/* Find task by PID */
struct turbo_task_info *turbo_find_task(pid_t pid)
{
    struct turbo_task_info *task_info;
    
    if (!turbo_sched)
        return NULL;
    
    list_for_each_entry(task_info, &turbo_sched->task_list, list) {
        if (task_info->pid == pid)
            return task_info;
    }
    
    return NULL;
}

/* Add task to scheduler */
int turbo_add_task(struct task_struct *task, int policy, int priority, int cpu_affinity)
{
    struct turbo_task_info *task_info;
    
    if (!turbo_sched || !task)
        return -EINVAL;
    
    /* Check if task already exists */
    task_info = turbo_find_task(task->pid);
    if (task_info)
        return -EEXIST;
    
    /* Allocate task info */
    task_info = kmalloc(sizeof(*task_info), GFP_KERNEL);
    if (!task_info)
        return -ENOMEM;
    
    /* Initialize task info */
    task_info->task = task;
    task_info->pid = task->pid;
    task_info->policy = policy;
    task_info->priority = priority;
    task_info->cpu_affinity = cpu_affinity;
    task_info->state = TURBO_TASK_RUNNING;
    task_info->cpu_time = 0;
    task_info->last_schedule = jiffies;
    spin_lock_init(&task_info->lock);
    
    /* Add to list */
    spin_lock(&turbo_sched->lock);
    list_add(&task_info->list, &turbo_sched->task_list);
    spin_unlock(&turbo_sched->lock);
    
    if (turbo_debug)
        printk(KERN_INFO "TurboSched: Added task %d with policy %d, priority %d, CPU %d\n",
               task->pid, policy, priority, cpu_affinity);
    
    return 0;
}

/* Remove task from scheduler */
int turbo_remove_task(pid_t pid)
{
    struct turbo_task_info *task_info;
    
    if (!turbo_sched)
        return -EINVAL;
    
    task_info = turbo_find_task(pid);
    if (!task_info)
        return -ENOENT;
    
    spin_lock(&turbo_sched->lock);
    list_del(&task_info->list);
    spin_unlock(&turbo_sched->lock);
    
    kfree(task_info);
    
    if (turbo_debug)
        printk(KERN_INFO "TurboSched: Removed task %d\n", pid);
    
    return 0;
}

/* Update task statistics */
int turbo_update_task_stats(pid_t pid)
{
    struct turbo_task_info *task_info;
    struct task_struct *task;
    cputime_t utime, stime;
    
    task_info = turbo_find_task(pid);
    if (!task_info)
        return -ENOENT;
    
    task = task_info->task;
    if (!task)
        return -EINVAL;
    
    spin_lock(&task_info->lock);
    
    /* Get CPU time */
    thread_group_cputime(task, &utime, &stime);
    task_info->cpu_time = cputime_to_jiffies(utime + stime);
    task_info->last_schedule = jiffies;
    
    spin_unlock(&task_info->lock);
    
    return 0;
}

/* Set task policy */
int turbo_set_policy(pid_t pid, int policy, int priority, int cpu_affinity)
{
    struct turbo_task_info *task_info;
    struct task_struct *task;
    
    task_info = turbo_find_task(pid);
    if (!task_info)
        return -ENOENT;
    
    task = task_info->task;
    if (!task)
        return -EINVAL;
    
    spin_lock(&task_info->lock);
    
    /* Update policy */
    task_info->policy = policy;
    task_info->priority = priority;
    task_info->cpu_affinity = cpu_affinity;
    
    /* Apply policy to task */
    if (policy == TURBO_POLICY_REALTIME) {
        struct sched_param param;
        param.sched_priority = priority;
        sched_setscheduler(task, SCHED_RR, &param);
    } else if (policy == TURBO_POLICY_QUBIT || policy == TURBO_POLICY_HPC) {
        /* Set high priority */
        set_user_nice(task, -20);
        task_info->cpu_affinity = cpumask_of(task_info->cpu_affinity);
    }
    
    spin_unlock(&task_info->lock);
    
    if (turbo_debug)
        printk(KERN_INFO "TurboSched: Set policy %d, priority %d, CPU %d for task %d\n",
               policy, priority, cpu_affinity, pid);
    
    return 0;
}

/* Get task policy */
int turbo_get_policy(pid_t pid, struct turbo_policy *policy)
{
    struct turbo_task_info *task_info;
    
    task_info = turbo_find_task(pid);
    if (!task_info)
        return -ENOENT;
    
    spin_lock(&task_info->lock);
    
    policy->pid = task_info->pid;
    policy->policy = task_info->policy;
    policy->priority = task_info->priority;
    policy->cpu_affinity = task_info->cpu_affinity;
    
    spin_unlock(&task_info->lock);
    
    return 0;
}

/* Set task priority */
int turbo_set_priority(pid_t pid, int nice_value, int rt_priority)
{
    struct turbo_task_info *task_info;
    struct task_struct *task;
    
    task_info = turbo_find_task(pid);
    if (!task_info)
        return -ENOENT;
    
    task = task_info->task;
    if (!task)
        return -EINVAL;
    
    spin_lock(&task_info->lock);
    
    /* Update priority */
    if (nice_value != 0) {
        set_user_nice(task, nice_value);
    }
    
    if (rt_priority > 0) {
        struct sched_param param;
        param.sched_priority = rt_priority;
        sched_setscheduler(task, SCHED_RR, &param);
    }
    
    task_info->priority = rt_priority;
    
    spin_unlock(&task_info->lock);
    
    if (turbo_debug)
        printk(KERN_INFO "TurboSched: Set priority %d, nice %d for task %d\n",
               rt_priority, nice_value, pid);
    
    return 0;
}

/* Get scheduler statistics */
int turbo_get_stats(struct turbo_stats *stats)
{
    struct turbo_task_info *task_info;
    int total_tasks = 0, realtime_tasks = 0, qubit_tasks = 0, hpc_tasks = 0;
    
    if (!turbo_sched || !stats)
        return -EINVAL;
    
    spin_lock(&turbo_sched->lock);
    
    list_for_each_entry(task_info, &turbo_sched->task_list, list) {
        total_tasks++;
        switch (task_info->policy) {
            case TURBO_POLICY_REALTIME:
                realtime_tasks++;
                break;
            case TURBO_POLICY_QUBIT:
                qubit_tasks++;
                break;
            case TURBO_POLICY_HPC:
                hpc_tasks++;
                break;
        }
    }
    
    stats->total_tasks = total_tasks;
    stats->realtime_tasks = realtime_tasks;
    stats->qubit_tasks = qubit_tasks;
    stats->hpc_tasks = hpc_tasks;
    stats->context_switches = turbo_sched->context_switches;
    stats->scheduler_overhead = turbo_sched->scheduler_overhead;
    
    spin_unlock(&turbo_sched->lock);
    
    return 0;
}

/* Enable scheduler */
int turbo_enable_scheduler(void)
{
    if (!turbo_sched)
        return -EINVAL;
    
    turbo_sched->enabled = true;
    
    if (turbo_debug)
        printk(KERN_INFO "TurboSched: Scheduler enabled\n");
    
    return 0;
}

/* Disable scheduler */
int turbo_disable_scheduler(void)
{
    if (!turbo_sched)
        return -EINVAL;
    
    turbo_sched->enabled = false;
    
    if (turbo_debug)
        printk(KERN_INFO "TurboSched: Scheduler disabled\n");
    
    return 0;
}

/* Balance load across CPUs */
void turbo_balance_load(void)
{
    struct turbo_task_info *task_info;
    int cpu_load[NR_CPUS] = {0};
    int min_load_cpu = 0, max_load_cpu = 0;
    
    if (!turbo_sched || !turbo_sched->enabled)
        return;
    
    /* Calculate CPU loads */
    list_for_each_entry(task_info, &turbo_sched->task_list, list) {
        if (task_info->policy == TURBO_POLICY_HPC || task_info->policy == TURBO_POLICY_QUBIT) {
            cpu_load[task_info->cpu_affinity]++;
        }
    }
    
    /* Find min and max load CPUs */
    for (int i = 0; i < NR_CPUS; i++) {
        if (cpu_online(i)) {
            if (cpu_load[i] < cpu_load[min_load_cpu])
                min_load_cpu = i;
            if (cpu_load[i] > cpu_load[max_load_cpu])
                max_load_cpu = i;
        }
    }
    
    /* Balance load if needed */
    if (cpu_load[max_load_cpu] - cpu_load[min_load_cpu] > 1) {
        list_for_each_entry(task_info, &turbo_sched->task_list, list) {
            if (task_info->cpu_affinity == max_load_cpu &&
                (task_info->policy == TURBO_POLICY_HPC || task_info->policy == TURBO_POLICY_QUBIT)) {
                
                task_info->cpu_affinity = min_load_cpu;
                
                if (turbo_debug)
                    printk(KERN_INFO "TurboSched: Moved task %d from CPU %d to CPU %d\n",
                           task_info->pid, max_load_cpu, min_load_cpu);
                
                break; /* Move one task at a time */
            }
        }
    }
}

/* Optimize CPU affinity for HPC tasks */
void turbo_optimize_cpu_affinity(void)
{
    struct turbo_task_info *task_info;
    cpumask_t hpc_mask, qubit_mask;
    int hpc_count = 0, qubit_count = 0;
    
    if (!turbo_sched || !turbo_sched->enabled)
        return;
    
    cpumask_clear(&hpc_mask);
    cpumask_clear(&qubit_mask);
    
    /* Count tasks and set affinity masks */
    list_for_each_entry(task_info, &turbo_sched->task_list, list) {
        if (task_info->policy == TURBO_POLICY_HPC) {
            cpumask_set_cpu(task_info->cpu_affinity, &hpc_mask);
            hpc_count++;
        } else if (task_info->policy == TURBO_POLICY_QUBIT) {
            cpumask_set_cpu(task_info->cpu_affinity, &qubit_mask);
            qubit_count++;
        }
    }
    
    /* Optimize: give HPC tasks dedicated CPUs if possible */
    if (hpc_count > 0 && qubit_count > 0) {
        int hpc_cpu = cpumask_first(cpu_online_mask);
        int qubit_cpu = cpumask_next(hpc_cpu, cpu_online_mask);
        
        list_for_each_entry(task_info, &turbo_sched->task_list, list) {
            if (task_info->policy == TURBO_POLICY_HPC && task_info->cpu_affinity != hpc_cpu) {
                task_info->cpu_affinity = hpc_cpu;
                if (turbo_debug)
                    printk(KERN_INFO "TurboSched: Optimized HPC task %d to CPU %d\n",
                           task_info->pid, hpc_cpu);
            } else if (task_info->policy == TURBO_POLICY_QUBIT && task_info->cpu_affinity != qubit_cpu) {
                task_info->cpu_affinity = qubit_cpu;
                if (turbo_debug)
                    printk(KERN_INFO "TurboSched: Optimized Qubit task %d to CPU %d\n",
                           task_info->pid, qubit_cpu);
            }
        }
    }
}

/* Main scheduler thread */
int turbo_scheduler_thread(void *data)
{
    struct turbo_scheduler *sched = (struct turbo_scheduler *)data;
    ktime_t next_update;
    
    if (!sched)
        return -EINVAL;
    
    sched->running = true;
    
    while (!kthread_should_stop()) {
        if (sched->enabled) {
            /* Update task statistics */
            struct turbo_task_info *task_info;
            list_for_each_entry(task_info, &sched->task_list, list) {
                turbo_update_task_stats(task_info->pid);
            }
            
            /* Balance load */
            turbo_balance_load();
            
            /* Optimize affinity */
            turbo_optimize_cpu_affinity();
            
            /* Update statistics */
            sched->context_switches++;
            sched->last_update = ktime_get();
        }
        
        /* Sleep for update interval */
        next_update = ktime_add_ms(sched->last_update, turbo_update_interval);
        ktime_t now = ktime_get();
        
        if (ktime_to_ns(next_update) > ktime_to_ns(now)) {
            ktime_t sleep_time = ktime_sub(next_update, now);
            msleep(ktime_to_ms(sleep_time));
        }
    }
    
    sched->running = false;
    return 0;
}

/* Schedule task */
void turbo_schedule_task(struct turbo_task_info *task_info)
{
    struct task_struct *task = task_info->task;
    
    if (!task || !task_info)
        return;
    
    /* Set CPU affinity */
    if (task_info->cpu_affinity >= 0 && task_info->cpu_affinity < NR_CPUS) {
        set_cpus_allowed_ptr(task, cpumask_of(task_info->cpu_affinity));
    }
    
    /* Set priority based on policy */
    switch (task_info->policy) {
        case TURBO_POLICY_REALTIME:
            {
                struct sched_param param;
                param.sched_priority = task_info->priority;
                sched_setscheduler(task, SCHED_RR, &param);
            }
            break;
        case TURBO_POLICY_QUBIT:
        case TURBO_POLICY_HPC:
            set_user_nice(task, -20); /* Highest priority */
            break;
        default:
            set_user_nice(task, 0);
            break;
    }
    
    /* Wake up task if needed */
    if (task_info->state == TURBO_TASK_WAITING) {
        wake_up_process(task);
        task_info->state = TURBO_TASK_RUNNING;
    }
}

/* IOCTL handler */
long turbo_sched_ioctl(struct file *file, unsigned int cmd, unsigned long arg)
{
    void __user *uarg = (void __user *)arg;
    int ret = 0;
    
    switch (cmd) {
        case TURBO_SET_POLICY: {
            struct turbo_policy policy;
            if (copy_from_user(&policy, uarg, sizeof(policy)))
                return -EFAULT;
            
            ret = turbo_set_policy(policy.pid, policy.policy, policy.priority, policy.cpu_affinity);
            break;
        }
        
        case TURBO_GET_POLICY: {
            struct turbo_policy policy;
            if (copy_from_user(&policy, uarg, sizeof(policy)))
                return -EFAULT;
            
            ret = turbo_get_policy(policy.pid, &policy);
            if (ret == 0 && copy_to_user(uarg, &policy, sizeof(policy)))
                ret = -EFAULT;
            break;
        }
        
        case TURBO_SET_PRIORITY: {
            struct turbo_priority priority;
            if (copy_from_user(&priority, uarg, sizeof(priority)))
                return -EFAULT;
            
            ret = turbo_set_priority(priority.pid, priority.nice_value, priority.rt_priority);
            break;
        }
        
        case TURBO_GET_STATS: {
            struct turbo_stats stats;
            ret = turbo_get_stats(&stats);
            if (ret == 0 && copy_to_user(uarg, &stats, sizeof(stats)))
                ret = -EFAULT;
            break;
        }
        
        case TURBO_ENABLE_SCHEDULER:
            ret = turbo_enable_scheduler();
            break;
        
        case TURBO_DISABLE_SCHEDULER:
            ret = turbo_disable_scheduler();
            break;
        
        default:
            ret = -ENOTTY;
            break;
    }
    
    return ret;
}

/* Module initialization */
int turbo_sched_init(void)
{
    int ret = 0;
    
    printk(KERN_INFO "TurboScheduler: Initializing module\n");
    
    /* Allocate scheduler structure */
    turbo_sched = kmalloc(sizeof(*turbo_sched), GFP_KERNEL);
    if (!turbo_sched) {
        ret = -ENOMEM;
        goto fail_alloc;
    }
    memset(turbo_sched, 0, sizeof(*turbo_sched));
    
    /* Initialize list and locks */
    INIT_LIST_HEAD(&turbo_sched->task_list);
    spin_lock_init(&turbo_sched->lock);
    
    /* Create character device */
    ret = register_chrdev(TURBO_SCHED_MAJOR, TURBO_SCHED_NAME, &turbo_sched_fops);
    if (ret < 0) {
        printk(KERN_WARNING "TurboScheduler: Can't register character device\n");
        goto fail_chrdev;
    }
    
    /* Start scheduler thread */
    turbo_sched->scheduler_thread = kthread_run(turbo_scheduler_thread, turbo_sched, "turbo_sched");
    if (IS_ERR(turbo_sched->scheduler_thread)) {
        ret = PTR_ERR(turbo_sched->scheduler_thread);
        printk(KERN_WARNING "TurboScheduler: Can't create scheduler thread\n");
        goto fail_thread;
    }
    
    /* Enable by default if requested */
    if (turbo_enabled) {
        turbo_sched->enabled = true;
        printk(KERN_INFO "TurboScheduler: Enabled by default\n");
    }
    
    printk(KERN_INFO "TurboScheduler: Module loaded successfully\n");
    return 0;
    
fail_thread:
    unregister_chrdev(TURBO_SCHED_MAJOR, TURBO_SCHED_NAME);
fail_chrdev:
    kfree(turbo_sched);
fail_alloc:
    return ret;
}

/* Module cleanup */
void turbo_sched_exit(void)
{
    if (turbo_sched) {
        /* Stop scheduler thread */
        if (turbo_sched->scheduler_thread) {
            kthread_stop(turbo_sched->scheduler_thread);
        }
        
        /* Clean up tasks */
        struct turbo_task_info *task_info, *tmp;
        list_for_each_entry_safe(task_info, tmp, &turbo_sched->task_list, list) {
            list_del(&task_info->list);
            kfree(task_info);
        }
        
        /* Unregister character device */
        unregister_chrdev(TURBO_SCHED_MAJOR, TURBO_SCHED_NAME);
        
        kfree(turbo_sched);
    }
    
    printk(KERN_INFO "TurboScheduler: Module unloaded\n");
}

module_init(turbo_sched_init);
module_exit(turbo_sched_exit);