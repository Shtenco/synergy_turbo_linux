/*
 * Turbo Scheduler Kernel Module Header
 * Copyright (C) 2026 - VirtualQubit HPC Team
 * 
 * Qubit-aware real-time scheduler for HPC workloads
 */

#ifndef _TURBO_SCHED_H
#define _TURBO_SCHED_H

#include <linux/module.h>
#include <linux/kernel.h>
#include <linux/init.h>
#include <linux/sched.h>
#include <linux/sched/signal.h>
#include <linux/sched/task.h>
#include <linux/sched/cputime.h>
#include <linux/slab.h>
#include <linux/spinlock.h>
#include <linux/kthread.h>
#include <linux/delay.h>
#include <linux/ktime.h>
#include <linux/hrtimer.h>

#define TURBO_SCHED_NAME "turbo_sched"
#define TURBO_SCHED_MAJOR 0

/* Scheduler policies */
#define TURBO_POLICY_NORMAL     0
#define TURBO_POLICY_REALTIME   1
#define TURBO_POLICY_QUBIT      2
#define TURBO_POLICY_HPC        3

/* Task states */
#define TURBO_TASK_RUNNING      0
#define TURBO_TASK_WAITING      1
#define TURBO_TASK_BLOCKED      2

/* IOCTL commands */
#define TURBO_SCHED_IOC_MAGIC 't'

#define TURBO_SET_POLICY       _IOW(TURBO_SCHED_IOC_MAGIC, 1, struct turbo_policy)
#define TURBO_GET_POLICY       _IOR(TURBO_SCHED_IOC_MAGIC, 2, struct turbo_policy)
#define TURBO_SET_PRIORITY     _IOW(TURBO_SCHED_IOC_MAGIC, 3, struct turbo_priority)
#define TURBO_GET_STATS        _IOR(TURBO_SCHED_IOC_MAGIC, 4, struct turbo_stats)
#define TURBO_ENABLE_SCHEDULER _IO(TURBO_SCHED_IOC_MAGIC, 5)
#define TURBO_DISABLE_SCHEDULER _IO(TURBO_SCHED_IOC_MAGIC, 6)

/* Data structures */
struct turbo_policy {
    pid_t pid;
    int policy;
    int priority;
    int cpu_affinity;
};

struct turbo_priority {
    pid_t pid;
    int nice_value;
    int rt_priority;
};

struct turbo_stats {
    unsigned long total_tasks;
    unsigned long realtime_tasks;
    unsigned long qubit_tasks;
    unsigned long hpc_tasks;
    unsigned long context_switches;
    unsigned long scheduler_overhead;
};

struct turbo_task_info {
    struct task_struct *task;
    pid_t pid;
    int policy;
    int priority;
    int cpu_affinity;
    int state;
    unsigned long cpu_time;
    unsigned long last_schedule;
    struct list_head list;
    spinlock_t lock;
};

struct turbo_scheduler {
    struct list_head task_list;
    spinlock_t lock;
    struct task_struct *scheduler_thread;
    bool enabled;
    bool running;
    unsigned long context_switches;
    unsigned long scheduler_overhead;
    ktime_t last_update;
};

/* Function declarations */
int turbo_sched_init(void);
void turbo_sched_exit(void);

/* Scheduler operations */
int turbo_set_policy(pid_t pid, int policy, int priority, int cpu_affinity);
int turbo_get_policy(pid_t pid, struct turbo_policy *policy);
int turbo_set_priority(pid_t pid, int nice_value, int rt_priority);
int turbo_get_stats(struct turbo_stats *stats);
int turbo_enable_scheduler(void);
int turbo_disable_scheduler(void);

/* Task management */
struct turbo_task_info *turbo_find_task(pid_t pid);
int turbo_add_task(struct task_struct *task, int policy, int priority, int cpu_affinity);
int turbo_remove_task(pid_t pid);
int turbo_update_task_stats(pid_t pid);

/* Scheduler core */
int turbo_scheduler_thread(void *data);
void turbo_schedule_task(struct turbo_task_info *task_info);
void turbo_balance_load(void);
void turbo_optimize_cpu_affinity(void);

#endif /* _TURBO_SCHED_H */