#!/usr/bin/env python3
# VirtualQubit Module Test Script

import os
import sys
import time
import ctypes
from vqubit.vqubit_python import VirtualQubitKernelAccelerated

def test_vqubit_module():
    print("=== Testing VirtualQubit Kernel Module ===")
    
    # Test kernel module availability
    if os.path.exists("/dev/vqubit"):
        print("✓ VirtualQubit device node exists")
    else:
        print("✗ VirtualQubit device node not found")
        return False
    
    # Test Python interface
    try:
        qubit = VirtualQubitKernelAccelerated(use_kernel=True)
        print(f"✓ VirtualQubit Python interface loaded (kernel: {qubit.use_kernel})")
        
        # Test basic operations
        test_data = b"Hello VirtualQubit Kernel!"
        
        if qubit.encode(0, test_data):
            print("✓ Encode operation successful")
        else:
            print("✗ Encode operation failed")
            return False
        
        decoded = qubit.decode(0)
        if decoded:
            print("✓ Decode operation successful")
        else:
            print("✗ Decode operation failed")
            return False
        
        if qubit.hadamard(0):
            print("✓ Hadamard transform successful")
        else:
            print("✗ Hadamard transform failed")
            return False
        
        if qubit.qft(0):
            print("✓ QFT operation successful")
        else:
            print("✗ QFT operation failed")
            return False
        
        measurement = qubit.measure(0)
        if measurement:
            print(f"✓ Measurement successful: result={measurement[0]}, probability={measurement[1]:.4f}")
        else:
            print("✗ Measurement failed")
            return False
        
        # Test performance
        print("\n--- Performance Test ---")
        start_time = time.time()
        
        for i in range(100):
            qubit.encode(0, test_data)
            qubit.hadamard(0)
            qubit.qft(0)
            qubit.decode(0)
        
        elapsed = time.time() - start_time
        print(f"✓ 100 operations completed in {elapsed:.4f} seconds")
        print(f"✓ Average: {elapsed/100*1000:.2f} ms per operation")
        
        return True
        
    except Exception as e:
        print(f"✗ Python interface test failed: {e}")
        return False

def test_turbo_sched_module():
    print("\n=== Testing Turbo Scheduler Module ===")
    
    if os.path.exists("/dev/turbo_sched"):
        print("✓ Turbo Scheduler device node exists")
    else:
        print("✗ Turbo Scheduler device node not found")
        return False
    
    # Test basic functionality
    try:
        # This would require additional Python bindings for turbo_sched
        # For now, just check if the device is accessible
        with open("/dev/turbo_sched", "r") as f:
            print("✓ Turbo Scheduler device is accessible")
        return True
    except Exception as e:
        print(f"✗ Turbo Scheduler test failed: {e}")
        return False

def main():
    print("VirtualQubit Kernel Modules Test Suite")
    print("=" * 50)
    
    vqubit_ok = test_vqubit_module()
    sched_ok = test_turbo_sched_module()
    
    print("\n" + "=" * 50)
    if vqubit_ok and sched_ok:
        print("✓ All tests passed!")
        return 0
    else:
        print("✗ Some tests failed!")
        return 1

if __name__ == "__main__":
    sys.exit(main())