#!/bin/bash
# Setup script for inside the Ubuntu VM
# This script configures the VM for VirtualQubit HPC optimizations

set -e

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

log_info() {
    echo -e "${BLUE}[INFO]${NC} $1"
}

log_success() {
    echo -e "${GREEN}[SUCCESS]${NC} $1"
}

log_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

log_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

# Check if running as root
check_root() {
    if [[ $EUID -ne 0 ]]; then
        log_error "This script must be run as root (use sudo)"
        exit 1
    fi
}

# Update system
update_system() {
    log_info "Updating system..."
    apt-get update
    apt-get upgrade -y
    log_success "System updated"
}

# Install required packages
install_packages() {
    log_info "Installing required packages..."
    
    # Install build tools and kernel headers
    apt-get install -y \
        build-essential \
        linux-headers-$(uname -r) \
        dkms \
        python3 \
        python3-pip \
        git \
        wget \
        curl \
        htop \
        iotop \
        sysstat \
        zstd \
        xxhash \
        libxxhash-dev
    
    # Install Python packages
    pip3 install numpy scipy matplotlib numba zstandard xxhash
    
    log_success "Required packages installed"
}

# Create VirtualQubit directory
create_directories() {
    log_info "Creating VirtualQubit directories..."
    
    mkdir -p /home/vboxuser/VirtualQubit
    mkdir -p /home/vboxuser/VirtualQubit/kernel_modules
    mkdir -p /home/vboxuser/VirtualQubit/scripts
    
    chown -R vboxuser:vboxuser /home/vboxuser/VirtualQubit
    
    log_success "Directories created"
}

# Copy kernel modules (assuming they're in shared folder or copied manually)
copy_modules() {
    log_info "Looking for kernel modules..."
    
    # Check shared folder
    if [[ -d "/media/sf_VirtualQubit" ]]; then
        log_info "Found shared folder, copying modules..."
        cp -r /media/sf_VirtualQubit/* /home/vboxuser/VirtualQubit/
        log_success "Modules copied from shared folder"
    elif [[ -d "/home/vboxuser/VirtualQubit/kernel_modules" ]]; then
        log_success "Modules already present"
    else
        log_warning "No kernel modules found. They need to be copied manually."
        log_info "Copy the kernel_modules directory to /home/vboxuser/VirtualQubit/"
    fi
}

# Configure system for optimal performance
configure_system() {
    log_info "Configuring system for optimal performance..."
    
    # CPU Governor
    log_info "Setting CPU governor to performance..."
    for cpu in /sys/devices/system/cpu/cpu*/cpufreq/scaling_governor; do
        if [[ -f "$cpu" ]]; then
            echo performance > "$cpu"
        fi
    done
    
    # Disable C-states
    log_info "Disabling C-states for maximum performance..."
    echo 1 > /sys/module/intel_idle/parameters/max_cstate 2>/dev/null || true
    
    # HugePages configuration
    log_info "Configuring HugePages..."
    echo 32768 > /proc/sys/vm/nr_hugepages
    
    # NUMA balancing
    log_info "Disabling NUMA balancing..."
    echo 0 > /proc/sys/kernel/numa_balancing
    
    # Disable transparent hugepages defrag
    log_info "Configuring transparent hugepages..."
    echo never > /sys/kernel/mm/transparent_hugepage/defrag 2>/dev/null || true
    
    # IRQ affinity optimization
    log_info "Optimizing IRQ affinity..."
    # This is a simplified version - in production, you'd want more sophisticated IRQ balancing
    
    # Save configuration to sysctl.conf
    cat >> /etc/sysctl.conf << EOF

# VirtualQubit HPC optimizations
vm.nr_hugepages = 32768
kernel.numa_balancing = 0
kernel.sched_min_granularity_ns = 10000000
kernel.sched_wakeup_granularity_ns = 5000000
EOF

    # Apply sysctl settings
    sysctl -p
    
    log_success "System configuration completed"
}

# Create startup script
create_startup_script() {
    log_info "Creating startup script..."
    
    cat > /etc/init.d/vqubit-startup << 'EOF'
#!/bin/bash
### BEGIN INIT INFO
# Provides:          vqubit-startup
# Required-Start:    $local_fs $remote_fs $network
# Required-Stop:     $local_fs $remote_fs $network
# Default-Start:     2 3 4 5
# Default-Stop:      0 1 6
# Short-Description: VirtualQubit HPC startup script
# Description:       Configure system for VirtualQubit HPC performance
### END INIT INFO

case "$1" in
    start)
        echo "Starting VirtualQubit HPC configuration..."
        
        # Load modules
        modprobe vqubit 2>/dev/null || true
        modprobe turbo_sched 2>/dev/null || true
        
        # Create device nodes
        if [[ ! -c "/dev/vqubit" ]]; then
            mknod /dev/vqubit c 0 0
            chmod 666 /dev/vqubit
        fi
        
        if [[ ! -c "/dev/turbo_sched" ]]; then
            mknod /dev/turbo_sched c 0 1
            chmod 666 /dev/turbo_sched
        fi
        
        # System optimizations
        for cpu in /sys/devices/system/cpu/cpu*/cpufreq/scaling_governor; do
            if [[ -f "$cpu" ]]; then
                echo performance > "$cpu"
            fi
        done
        
        echo 32768 > /proc/sys/vm/nr_hugepages
        echo 0 > /proc/sys/kernel/numa_balancing
        
        echo "VirtualQubit HPC configuration started"
        ;;
    stop)
        echo "Stopping VirtualQubit HPC configuration..."
        # Cleanup can be added here if needed
        ;;
    restart)
        $0 stop
        sleep 1
        $0 start
        ;;
    *)
        echo "Usage: $0 {start|stop|restart}"
        exit 1
        ;;
esac

exit 0
EOF

    chmod +x /etc/init.d/vqubit-startup
    
    # Enable startup script
    update-rc.d vqubit-startup defaults
    
    log_success "Startup script created and enabled"
}

# Create desktop shortcut
create_desktop_shortcut() {
    log_info "Creating desktop shortcut..."
    
    cat > /home/vboxuser/Desktop/VirtualQubit.desktop << 'EOF'
[Desktop Entry]
Version=1.0
Type=Application
Name=VirtualQubit HPC
Comment=VirtualQubit HPC Performance Suite
Exec=gnome-terminal -- bash -c "cd /home/vboxuser/VirtualQubit && python3 test_modules.py; read -p 'Press Enter to close...'"
Icon=utilities-terminal
Terminal=false
Categories=Development;Science;Education;
EOF

    chmod +x /home/vboxuser/Desktop/VirtualQubit.desktop
    chown vboxuser:vboxuser /home/vboxuser/Desktop/VirtualQubit.desktop
    
    log_success "Desktop shortcut created"
}

# Create test script
create_test_script() {
    log_info "Creating test script..."
    
    cat > /home/vboxuser/VirtualQubit/test_setup.py << 'EOF'
#!/usr/bin/env python3
# VirtualQubit Setup Test Script

import os
import sys
import time

def test_system_optimizations():
    print("=== Testing System Optimizations ===")
    
    # Test HugePages
    try:
        with open('/proc/sys/vm/nr_hugepages', 'r') as f:
            hugepages = int(f.read().strip())
        print(f"✓ HugePages configured: {hugepages}")
    except:
        print("✗ HugePages not configured")
    
    # Test NUMA balancing
    try:
        with open('/proc/sys/kernel/numa_balancing', 'r') as f:
            numa_balancing = int(f.read().strip())
        print(f"✓ NUMA balancing: {'disabled' if numa_balancing == 0 else 'enabled'}")
    except:
        print("✗ NUMA balancing status unknown")
    
    # Test CPU governor
    cpu_governor = None
    try:
        for cpu in os.listdir('/sys/devices/system/cpu/'):
            if cpu.startswith('cpu') and cpu[3:].isdigit():
                governor_file = f'/sys/devices/system/cpu/{cpu}/cpufreq/scaling_governor'
                if os.path.exists(governor_file):
                    with open(governor_file, 'r') as f:
                        governor = f.read().strip()
                        cpu_governor = governor
                        break
        if cpu_governor:
            print(f"✓ CPU governor: {cpu_governor}")
        else:
            print("✗ CPU governor not found")
    except:
        print("✗ CPU governor status unknown")

def test_python_packages():
    print("\n=== Testing Python Packages ===")
    
    packages = ['numpy', 'scipy', 'matplotlib', 'numba', 'zstandard', 'xxhash']
    
    for package in packages:
        try:
            __import__(package)
            print(f"✓ {package} available")
        except ImportError:
            print(f"✗ {package} not available")

def test_kernel_modules():
    print("\n=== Testing Kernel Modules ===")
    
    # Check if device nodes exist
    if os.path.exists('/dev/vqubit'):
        print("✓ VirtualQubit device node exists")
    else:
        print("✗ VirtualQubit device node not found")
    
    if os.path.exists('/dev/turbo_sched'):
        print("✓ Turbo Scheduler device node exists")
    else:
        print("✗ Turbo Scheduler device node not found")
    
    # Check if modules are loaded
    try:
        with open('/proc/modules', 'r') as f:
            modules = f.read()
        
        if 'vqubit' in modules:
            print("✓ VirtualQubit module loaded")
        else:
            print("✗ VirtualQubit module not loaded")
        
        if 'turbo_sched' in modules:
            print("✓ Turbo Scheduler module loaded")
        else:
            print("✗ Turbo Scheduler module not loaded")
    except:
        print("✗ Could not check loaded modules")

def main():
    print("VirtualQubit HPC Setup Test")
    print("=" * 40)
    
    test_system_optimizations()
    test_python_packages()
    test_kernel_modules()
    
    print("\n" + "=" * 40)
    print("Setup test completed!")
    print("\nNext steps:")
    print("1. Copy kernel modules to /home/vboxuser/VirtualQubit/")
    print("2. Run: sudo ./install_kernel_modules.sh")
    print("3. Reboot the VM")
    print("4. Run: ./test_modules.py")

if __name__ == "__main__":
    main()
EOF

    chmod +x /home/vboxuser/VirtualQubit/test_setup.py
    chown vboxuser:vboxuser /home/vboxuser/VirtualQubit/test_setup.py
    
    log_success "Test script created"
}

# Main function
main() {
    echo "VirtualQubit HPC VM Setup"
    echo "========================="
    
    check_root
    update_system
    install_packages
    create_directories
    copy_modules
    configure_system
    create_startup_script
    create_desktop_shortcut
    create_test_script
    
    echo ""
    log_success "VM setup completed successfully!"
    echo ""
    echo "Next steps:"
    echo "1. Copy kernel modules to /home/vboxuser/VirtualQubit/"
    echo "2. Run: sudo ./install_kernel_modules.sh"
    echo "3. Reboot the VM"
    echo "4. Run: ./test_modules.py"
    echo ""
    echo "You can also run: python3 test_setup.py"
    echo "to verify the current setup."
}

# Run main function
main "$@"