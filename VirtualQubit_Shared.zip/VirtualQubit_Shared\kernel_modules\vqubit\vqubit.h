/*
 * VirtualQubit Kernel Module Header
 * Copyright (C) 2026 - VirtualQubit HPC Team
 * 
 * Kernel-space implementation of virtual qubits for HPC acceleration
 */

#ifndef _VQUBIT_H
#define _VQUBIT_H

#include <linux/module.h>
#include <linux/kernel.h>
#include <linux/init.h>
#include <linux/fs.h>
#include <linux/cdev.h>
#include <linux/device.h>
#include <linux/slab.h>
#include <linux/uaccess.h>
#include <linux/ioctl.h>
#include <linux/sched.h>
#include <linux/mm.h>
#include <linux/vmalloc.h>
#include <asm/fpu/api.h>
#include <asm/avx512fintrin.h>

#define VQUBIT_MAJOR 0
#define VQUBIT_NAME "vqubit"
#define VQUBIT_CLASS_NAME "vqubit_class"

/* IOCTL commands */
#define VQUBIT_IOC_MAGIC 'v'

#define VQ_HADAMARD    _IOW(VQUBIT_IOC_MAGIC, 1, struct vq_operation)
#define VQ_QFT         _IOW(VQUBIT_IOC_MAGIC, 2, struct vq_operation)
#define VQ_AMPLITUDE   _IOW(VQUBIT_IOC_MAGIC, 3, struct vq_operation)
#define VQ_ENCODE      _IOW(VQUBIT_IOC_MAGIC, 4, struct vq_data)
#define VQ_DECODE      _IOR(VQUBIT_IOC_MAGIC, 5, struct vq_data)
#define VQ_MEASURE     _IOR(VQUBIT_IOC_MAGIC, 6, struct vq_measurement)
#define VQ_BATCH_OP    _IOW(VQUBIT_IOC_MAGIC, 7, struct vq_batch_operation)

/* Constants */
#define VQ_STATES 256
#define VQ_QCORES 8
#define VQ_BLOCK_SIZE 256

/* Data structures */
struct vq_data {
    void __user *data;
    size_t length;
    int qubit_id;
};

struct vq_operation {
    int qubit_id;
    int operation_type;
    void __user *input;
    void __user *output;
    size_t length;
};

struct vq_measurement {
    int qubit_id;
    int result;
    float probability;
};

struct vq_batch_operation {
    int operation_type;
    int num_qubits;
    void __user *input_data;
    void __user *output_data;
    size_t data_length;
};

/* Qubit state structure */
struct vq_qubit_state {
    int qubit_id;
    bool initialized;
    bool locked;
    spinlock_t lock;
    
    /* Quantum state vectors */
    float *amplitudes;        /* Real amplitudes */
    float *phases;           /* Phase information */
    complex float *state;    /* Complex state vector */
    
    /* Statistics */
    unsigned long ops_hadamard;
    unsigned long ops_qft;
    unsigned long ops_amplitude;
    unsigned long ops_measure;
};

/* Device structure */
struct vqubit_device {
    struct cdev cdev;
    struct class *class;
    struct device *device;
    dev_t devno;
    
    /* Qubit array */
    struct vq_qubit_state qubits[VQ_QCORES];
    
    /* Global statistics */
    unsigned long total_operations;
    unsigned long total_errors;
    
    /* Memory management */
    void *memory_pool;
    size_t pool_size;
};

/* Function declarations */
int vqubit_init(void);
void vqubit_exit(void);

/* Core quantum operations */
int vq_fwht(float *data, size_t length);
int vq_qft(complex float *data, size_t length);
int vq_amplitude_search(complex float *psi, complex float *query, size_t length, float *overlap);
int vq_encode_data(struct vq_qubit_state *qubit, const unsigned char *data, size_t length);
int vq_decode_data(struct vq_qubit_state *qubit, unsigned char *data, size_t length);

/* Memory management */
int vq_allocate_qubit_memory(struct vq_qubit_state *qubit);
void vq_free_qubit_memory(struct vq_qubit_state *qubit);

/* Device operations */
long vqubit_ioctl(struct file *file, unsigned int cmd, unsigned long arg);
int vqubit_open(struct inode *inode, struct file *file);
int vqubit_release(struct inode *inode, struct file *file);

#endif /* _VQUBIT_H */